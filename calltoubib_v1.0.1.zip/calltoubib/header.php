<header>

<h1>Bienvenue sur CALLTOUBIB</h1>
<!-- menu de navigation -->
<nav class="menu-nav">
    <ul>
        <li class="btn"><a href="index.php">Accueil</a></li>
        <li class="btn"><a href="patient.php">Patient</a></li>
        <li class="btn"><a href="medecin.php">Praticien</a></li>
        <li class="btn"><a href="login.php">Connexion</a></li>
        <li class="btn"><a href="contact.php">Contact</a></li>
    </ul>
</nav>
</header>